function getCookie(name) {
    let cookieValue = null;
    if (document.cookie) {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            // Does this cookie string begin with the name we want?
            if (cookie.startsWith(name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

document.addEventListener("DOMContentLoaded", function () {
    let btns = document.querySelectorAll(".mt-2 button");

    btns.forEach(btn => {
        btn.addEventListener("click", addToCart);
    });

    function addToCart(e) {
        let product_id = e.currentTarget.value;

        let url = "/add_to_cart";

        let data = { id: product_id };

        fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                'X-CSRFToken': csrftoken
            },
            body: JSON.stringify(data)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Network response was not ok (${response.status})`);
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            // Optionally, you can perform additional actions after a successful response.
        })
        .catch(error => {
            console.log(error);
            // Handle errors, e.g., display an error message to the user.
        });
    }
});


