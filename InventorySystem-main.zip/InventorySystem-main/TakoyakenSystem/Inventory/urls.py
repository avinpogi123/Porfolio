from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

#dito ung parang paths / url nila
#nakaconnect to sa views.py (kung ano mga function don, dapat nakalagay din dto)

urlpatterns = [
    path('', views.signin, name='sigin'),  
    path('signup/', views.signup, name='signup'),
    path('signin/', views.signin, name='signin'),
    path('logout/', views.logout, name='logout'),
    path('inventory/', views.inventory, name='inventory'),
    path('customer/', views.customer, name='customer'),
    path('history/', views.history, name='history'),
    path('orderHistory/', views.orderHistory, name='orderHistory'),
    path('transaction/', views.transaction, name='transaction'),
   
    path('addProduct/', views.addProduct, name='addProduct'),
    path('updateCustomer/<int:pk>', views.updateCustomer, name='updateCustomer'),
    path('addCustomer/', views.addCustomer, name='addCustomer'),
    path('deleteCustomer/<int:pk>', views.deleteCustomer, name='deleteCustomer'),




    path('order/', views.order, name='order'),
    path('userTransaction/', views.userTransaction, name='userTransaction'),
    path('cart/', views.cart, name='cart'),
    path('checkout_view/', views.checkout_view, name="checkout_view"),
    path('invoice/', views.invoice, name="invoice"),

    path('forgotPassword/', auth_views.PasswordResetView.as_view(template_name="forgotPassword.html"), name='forgotPassword'),
    path('inboxPassword/', auth_views.PasswordResetDoneView.as_view(template_name= "inboxPassword.html"), name='password_reset_done'),
    path('resetPassword/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name="resetPassword.html"),name='password_reset_confirm'),
    path('messagePassword/', auth_views.PasswordResetCompleteView.as_view(template_name="messagePassword.html"),name='password_reset_complete'),

#changePassword

    #dasd

    #path('accessDenied/', views.accessDenied, name='accessDenied'),

    path('updateItem/<int:pk>', views.updateItem, name='updateItem'),
    path('deleteItem/<int:pk>', views.deleteItem, name='deleteItem'),
    path('addProduct/', views.addProduct, name='addProduct'),

    path('add_to_cart', views.add_to_cart, name='add_to_cart'),
    path('remove_from_cart/<int:product_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('update_cart_quantity', views.update_cart_quantity, name='update_cart_quantity'),
    path('get_cart_data/', views.get_cart_data, name='get_cart_data'),

    path('generate_invoice_pdf/<int:transaction_id>/', views.generate_invoice_pdf, name='generate_invoice_pdf'),
    path('print_invoice/', views.print_invoice, name='print_invoice'),
    path('save_transaction_pdf',views.save_transaction_pdf, name='save_transaction_pdf'),
    path('save_transaction_time/', views.save_transaction_time, name='save_transaction_time'),
    path('checkout_api/', views.checkout_api, name='checkout_api'),
    path('save_transaction/', views.save_transaction, name='save_transaction'),
     path('checkout_api/save_transaction/', views.save_transaction, name='save_transaction'),
    


]

    



  