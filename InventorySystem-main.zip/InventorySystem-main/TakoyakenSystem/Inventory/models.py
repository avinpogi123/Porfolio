from django.utils import timezone

from uuid import uuid4
from django import forms
from django.db import models
from django.forms import Form
from django.contrib.auth.models import User



# Create your models here.
class Inventory(models.Model):
    category = models.CharField(max_length=50, null=False, blank=False)
    product_id = models.AutoField(primary_key=True)
    product_name = models.CharField(max_length=50, null=False, blank=False)
    unit_price = models.DecimalField(max_digits=19, decimal_places=2, null=True, blank=False)
    stocks = models.IntegerField(null=False, blank=False)
    selected = models.BooleanField(default=False)
    # stock_Date = models.DateField(auto_now=True)
    # sales_Date = models.DateField(auto_now=True)
    
    def __str__(self):
        return self.product_name
    
class Customer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name = 'customer', null=True, blank=True)
    branch_name = models.CharField(max_length=50, null=False, blank=False)
    email = models.EmailField(max_length=254, null=True, blank=True)
    phone_number = models.CharField(max_length=15, null=True, blank=True)
    address = models.TextField(null=True, blank=True)

    def __str__(self)-> str:
        return self.branch_name
    
    @property
    def cart(self):
        # Assuming each user has one cart associated with them
        return Cart.objects.get(user=self.user)



class Cart(models.Model):
    id = models.UUIDField(default=uuid4, primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)

    def __str__(self):
        return str(self.id)
    
    def remove_cart_item(self, cart_item):
        cart_item.delete()
    
    @property
    def total_price(self):
        cartitems = self.cartitems.all()
        total = sum([item.price for item in cartitems])
        return total
    
class CartItem(models.Model):
    product = models.ForeignKey(Inventory, on_delete = models.CASCADE, related_name='items')
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name='cartitems')
    quantity = models.IntegerField(default=0)

    def __str__(self):
        return str(self.product.product_name)
    
    @property
    def price(self):
        new_price = self.product.unit_price * self.quantity
        return new_price
    

class Transaction(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, null=True)
    invoice_pdf = models.FileField(upload_to='invoice_pdfs/', null=True, blank=True)
    time_clicked = models.DateTimeField(default=timezone.now, null=True, blank=True)


    def __str__(self):
        return str(self.cart.id)