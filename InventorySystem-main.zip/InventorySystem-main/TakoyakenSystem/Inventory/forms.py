from django import forms
from django.forms import Form
from.models import Inventory, Transaction
from.models import Customer

class add_ProductForm(forms.ModelForm):
    product_name = forms.CharField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Product Name",
            "class": "form-control fs-3 mb-3",
             
        }),
        label=""
    )
    category = forms.CharField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Category",
            "class": "form-control fs-3",
            
        }),
        label=""
    )
    unit_price = forms.CharField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Unit Price",
            "class": "form-control fs-3", 
        }),
        label=""
    )
    stocks = forms.CharField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Stocks",
            "class": "form-control fs-3 ",
        }),
        label=""
    )
    
    class Meta:
        model = Inventory
        exclude = ("user", )

class add_CustomerForm(forms.ModelForm):
    branch_name = forms.CharField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Branch Name",
            "class": "form-control fs-3 mb-3",
             
        }),
        label=""
    )
    email = forms.EmailField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Email",
            "class": "form-control fs-3",
            
        }),
        label=""
    )
    phone_number = forms.IntegerField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Contact Number",
            "class": "form-control fs-3", 
        }),
        label=""
    )
    address = forms.CharField(
        required=True,
        widget=forms.widgets.TextInput(attrs={
            "placeholder": "Address",
            "class": "form-control fs-3 ",
        }),
        label=""
    )
    
    class Meta:
        model = Customer
        exclude = ("user", )        

