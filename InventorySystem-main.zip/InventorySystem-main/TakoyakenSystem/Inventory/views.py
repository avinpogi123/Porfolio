import json
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout as auth_logout
from .models import *
from django.core.mail import send_mail
from .forms import add_ProductForm, add_CustomerForm
from django.contrib.auth.decorators import login_required
from .utils import generate_invoice_pdf
from django.core.files import File
from django.shortcuts import render
from django.template.loader import get_template
from django.core.files.base import ContentFile
from .models import Transaction
from django.conf import settings
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST


# Create your views here.
#dito lalagay ung mga bagong page ng html


def signup(request):

    if request.method == "POST":
        email = request.POST['email']
        username = request.POST['username']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']
        
        if pass1 == pass2:
            if User.objects.filter(email=email).exists():
                messages.info(request, 'Email Already Used')
                return redirect('signup')
            
            elif User.objects.filter(username=username).exists():
                messages.info(request, 'Username Already Used')
                return redirect('signup')
            else:
                myuser = User.objects.create_user(username=username, email=email, password=pass1)
                myuser.save()
                return redirect('signin')
        else:
            messages.info(request, 'Password not same')
            return redirect('signup')
    else:    
        return render(request, 'signup.html', {})
    

def signin(request):

    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']

        user = authenticate(username=username, password=pass1)

        if user is not None:
            login(request,  user)
           
            
            if user.is_staff or user.is_superuser:
                return redirect ('inventory')

            else:
                return redirect('order')
        
        else:
            messages.info(request, ("There was an error logging in, Try Again"))
            return redirect('signin')

    else:
        return render(request, 'signin.html', {})   


def inventory(request):
    inventory = Inventory.objects.all() 
    return render(request, 'inventory.html', {'inventory':inventory})

def forgotPassword(request):
    return render(request, 'forgotPassword.html', {})

#CRUD SHIT PALAGAY LANG COMMENT NAKAKAHILO NA E
def updateItem(request, pk):
    product = Inventory.objects.get(product_id=pk)
    if request.method == 'POST':
        form = add_ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect ('inventory')
        
    return render(request, 'updateItem.html', {'product': product})

def deleteItem(request,pk):
    deleteIt = Inventory.objects.get(product_id=pk)
    deleteIt.delete()
    messages.success(request, "Item Deleted Successfully...")
    return redirect('inventory')


def addProduct(request):
    if request.method == 'POST':
        form = add_ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('inventory')
    else:
        form = add_ProductForm()

    return render(request, 'addproduct.html', {'form': form})
    


def updateCustomer(request, pk):
    customers = Customer.objects.get(id=pk)
    if request.method == 'POST':
        form = add_CustomerForm(request.POST, instance=customers)
        if form.is_valid():
            form.save()
            return redirect ('customer')
    
    return render(request, 'updateCustomer.html', {'customers':customers})


def deleteCustomer(request, pk):
    deleteIt = Customer.objects.get(id = pk)
    deleteIt.delete()
    messages.success(request, "Customer Deleted Successfully...")
    return redirect('customer')


def addCustomer(request):
    if request.method == 'POST':
        form = add_CustomerForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('customer')
    else:
        form = add_CustomerForm()

    return render(request, 'addCustomer.html', {'form': form})

def customer(request):
    customers = Customer.objects.all()
    return render(request, 'customer.html', {'customers':customers})

def history(request):
    return render(request, 'history.html', {})

def orderHistory(request):
    return render(request, 'orderHistory.html', {})

def transaction(request):
    return render(request, 'transaction.html', {})

def logout(request):
    auth_logout(request)
    return redirect('signin')

def resetPassword(request, token):
    profile_obj = Customer.objects.get(forget_password_token = token)
    print(profile_obj)

    return render(request, 'resetPassword.html', {})

def messagePassword(request):
    return render(request, 'messagePassword.html', {})

def inboxPassword(request):
    return render(request, 'inboxPassword.html', {})


#def accessDenied(request):
    #return render(request, 'accessDenied.html', {})    

#User/Customer: 

def order(request):
    products = Inventory.objects.all()
    return render(request, 'order.html', {'products': products})

def userTransaction(request):
    return render(request, 'userTransaction.html',{})

def cart(request):
    
    cart = None
    cartitems = []

    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user = request.user, completed = False)
        cartitems = cart.cartitems.all()

    return render(request, 'cart.html', {"cart":cart, "items":cartitems})

def get_cart_data(request):
    # Logic to fetch and return cart data in a JSON format
    # Example: Get cart items and quantities for the current user
    cart_data = [
        {'product_id': item.product.product_id, 'quantity': item.quantity}
        for item in request.user.customer.cart.cartitems.all()
    ]

    return JsonResponse(cart_data, safe=False)

def add_to_cart(request):
    data = json.loads(request.body)
    product_id = data['id']
    product = Inventory.objects.get(product_id = product_id)

    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user = request.user, completed=False)
        cartitem, created = CartItem.objects.get_or_create(cart=cart, product=product)
        cartitem.quantity +=1
        cartitem.save()
    return JsonResponse("it is working", safe=False)

@login_required
def update_cart_quantity(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        product_id = data.get('id')
        quantity = data.get('quantity')

        if product_id and quantity is not None:
            try:
                cart_item = CartItem.objects.get(product_id=product_id, cart__user=request.user)
                cart_item.quantity = quantity
                cart_item.save()
                return JsonResponse({'success': True, 'message': 'Quantity updated successfully'})
            except CartItem.DoesNotExist:
                return JsonResponse({'success': False, 'message': 'Cart item not found'})
        else:
            return JsonResponse({'success': False, 'message': 'Invalid data received'})

    return JsonResponse({'success': False, 'message': 'Invalid request method'})

@login_required
def remove_from_cart(request, product_id):
    try:
        # Check if the user has a related customer
        if request.user.customer:
            # Get the cart item related to the user and the specified product_id
            cart_item = CartItem.objects.get(product_id=product_id, cart=request.user.customer.cart)
            cart_item.delete()
        else:
            # Handle the case where the user has no associated customer
            # You can redirect the user to an appropriate page or show an error message
            return render(request, 'no_customer.html')  # Create a template for handling this case
    except CartItem.DoesNotExist:
        # Handle the case where the specified product_id is not in the cart
        # You can redirect the user to an appropriate page or show an error message
        return render(request, 'product_not_in_cart.html')  # Create a template for handling this case
    
    return redirect('cart')  # Redirect to the cart page after removing the product


def print_invoice(request):
    # Your existing code for printing the invoice

    # Assuming you have access to the current user's cart
    cart = request.user.customer.cart

    # Create a new Transaction instance and associate it with the cart
    transaction = Transaction.objects.create(cart=cart)

    # Save the PDF and invoice file paths in the Transaction model
    transaction.invoice_pdf.name = 'path/to/invoice_pdf.pdf'  # Replace with your actual file path
    transaction.invoice.name = 'path/to/invoice.pdf'  # Replace with your actual file path
    transaction.save()

    # Your existing code for rendering the invoice template
    return render(request, 'your_invoice_template.html', {'transaction': transaction})


def userTransaction(request):
    transactions = Transaction.objects.all()
    return render(request, 'userTransaction.html', {'transactions': transactions})

def checkout_view(request):
    cart = None
    cartitems = []

    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user = request.user, completed = False)
        cartitems = cart.cartitems.all()

    return render(request, 'checkout_view.html', {"cart":cart, "items":cartitems})

def invoice(request):
    cart = None
    cartitems = []

    if request.user.is_authenticated:
        cart, created = Cart.objects.get_or_create(user = request.user, completed = False)
        cartitems = cart.cartitems.all()

    return render(request, 'invoice.html', {"cart":cart, "items":cartitems})
    #return render(request, "checkout.html")


@csrf_exempt
def save_transaction_time(request):
    if request.method == 'POST':
        # Get the time from the AJAX request
        time_clicked = request.POST.get('time_clicked')

        # Create a new Transaction instance and save the time
        transaction = Transaction.objects.create()
        transaction.time_clicked = timezone.datetime.fromisoformat(time_clicked)
        transaction.save()

        return JsonResponse({'status': 'success'})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})
    

@csrf_exempt
def save_transaction_pdf(request):
    if request.method == 'POST':
        try:
            # Get the PDF and time from the AJAX request
            pdf = request.FILES.get('pdf')
            time_clicked = request.POST.get('time_clicked')
            cart_id = request.POST.get('cart_id')

            print('Received PDF:', pdf)  # Check if PDF is received
            print('Received Time:', time_clicked)  # Check if time is received

            # Create a new Transaction instance, save the PDF, and set the time
            transaction = Transaction.objects.create(cart_id=cart_id)
            transaction.invoice_pdf.save('invoice.pdf', pdf)
            transaction.time_clicked = timezone.datetime.fromisoformat(time_clicked)
            transaction.save()

            return JsonResponse({'status': 'success'})
        except Exception as e:
            print('Error saving PDF:', str(e))
            return JsonResponse({'status': 'error', 'message': 'Error saving PDF'})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@csrf_exempt
def save_transaction_time(request):
    if request.method == 'POST':
        # Get the time from the AJAX request
        time_clicked = request.POST.get('time_clicked')
        cart_id = request.POST.get('cart_id')

        # Get the Cart instance based on the provided cart_id
        cart = get_object_or_404(Cart, id=cart_id)

        # Create a new Transaction instance and associate it with the cart
        transaction = Transaction.objects.create(cart=cart, time_clicked=timezone.datetime.fromisoformat(time_clicked))

        return JsonResponse({'status': 'success'})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})

@login_required
@require_POST
def checkout_api(request):
    # Assuming you have a cart object stored in request.user.customer.cart
    cart = request.user.customer.cart

    if cart:

        # Save the transaction
        transaction = Transaction.objects.create(cart=cart)
        transaction.save()

        # Clear the cart after successful checkout
        cart.completed = True
        cart.save()

        return JsonResponse({'status': 'success', 'message': 'Transaction successful'})

    return JsonResponse({'status': 'error', 'message': 'Transaction failed'})



@csrf_exempt
def save_transaction(request):
    if request.method == 'POST':
        try:
            cart_id = request.POST.get('cart_id')
            # Retrieve the cart and create a new Transaction
            cart = Cart.objects.get(id=cart_id)
            transaction = Transaction.objects.create(cart=cart)

            return JsonResponse({'status': 'success'})
        except Exception as e:
            print('Error saving transaction:', str(e))
            return JsonResponse({'status': 'error', 'message': 'Error saving transaction'})
    else:
        return JsonResponse({'status': 'error', 'message': 'Invalid request method'})
    

