from django.http import HttpResponse
from reportlab.pdfgen import canvas

def generate_invoice_pdf(cart):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename=invoice_{cart.id}.pdf'

    # Create the PDF document
    p = canvas.Canvas(response)
    p.drawString(100, 800, f"Invoice for Cart ID: {cart.id}")
    # Add more content as needed
    p.showPage()
    p.save()

    return response